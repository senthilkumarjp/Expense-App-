import React from "react";
import "./App.css";
import Expenses from "./components/Expenses";

function App() {
  const expenses = [
    {
      title: "Bank Loan",
      amount: 2000,
      date: new Date(2022, 7, 12),
    },
    {
      title: "groceries",
      amount: 1000,
      date: new Date(2022, 4, 3),
    },
    {
      title: "Car Insurance",
      amount: 5000,
      date: new Date(2022, 7, 9),
    },
    {
      title: "Car Insurance",
      amount: 5000,
      date: new Date(2022, 7, 9),
    },
  ];


// return  React.createElement(
//   'div',
//   {},
//   React.createElement('h1',{},'Expense App'),
//   React.createElement(Expenses, {expenses:expenses})
// )
  return (
    <div>
      <h1>Expense App</h1>
      <Expenses expenses={expenses}></Expenses>
    </div>
  );
}

export default App;
