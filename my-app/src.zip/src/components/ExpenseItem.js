import Card from './Card';
import ExpenseDate from './ExpenseDate';
import './ExpenseItem.css';

function ExpenseItem(props) {
// const expenseDate = new Date(2022,7,7);
// const expenseName = 'Car Insurance';
// const expenseAmount = 2000;


  return (
    <Card className='expense-item'>
     <ExpenseDate date={props.date}></ExpenseDate>
      <div className='expense-item__description '>
        <h2>{props.title}</h2>
        <div className='expense-item__price'>Rs.{props.amount}</div>
      </div>
    </Card>
  );
}

export default ExpenseItem;
